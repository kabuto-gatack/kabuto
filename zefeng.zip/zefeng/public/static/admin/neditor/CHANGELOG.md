<a name="2.1.6"></a>
## [2.1.6](https://github.com/notadd/neditor/compare/2.1.2...2.1.6) (2018-10-11)


### Bug Fixes

* **dialogs/video:** amend default field, fix [#61](https://github.com/notadd/neditor/issues/61) ([a840cd5](https://github.com/notadd/neditor/commit/a840cd5))
* **file:** delete package-lock.json ([43ef29d](https://github.com/notadd/neditor/commit/43ef29d))


### Features

* **gitignore:** add package-lock.json ([fc5ab46](https://github.com/notadd/neditor/commit/fc5ab46))
* **upload:** amend upload service ([8571761](https://github.com/notadd/neditor/commit/8571761))



<a name="2.1.2"></a>
## [2.1.2](https://github.com/notadd/neditor/compare/2.1.1...2.1.2) (2018-08-31)


### Bug Fixes

* **button icon:** change toolbar search-replace button icon ([feaa0e0](https://github.com/notadd/neditor/commit/feaa0e0))
* **dialogs/video:** amend service name ([209c3cd](https://github.com/notadd/neditor/commit/209c3cd))



<a name="2.1.1"></a>
## [2.1.1](https://github.com/notadd/neditor/compare/2.1.0...2.1.1) (2018-08-29)


### Bug Fixes

* **adapter:** remove debug log ([3fb6c0a](https://github.com/notadd/neditor/commit/3fb6c0a))
* **service:** amend neditor.service ([17d0419](https://github.com/notadd/neditor/commit/17d0419))


### Features

* update build config ([b3b2c5f](https://github.com/notadd/neditor/commit/b3b2c5f))
* **config:** amend neditor.config ([d868995](https://github.com/notadd/neditor/commit/d868995))



