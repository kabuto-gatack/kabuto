<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Friend extends Model
{
    //去掉默认时间戳
    public $timestamps = false;
    
}
