<?php
//后台静态资源文件路径
define("__ADMIN__","static/admin");
//前台静态资源文件路径
define("__INDEX__","static/index");